package View;

public interface ChessView {

  void render();

  void flip();

}
