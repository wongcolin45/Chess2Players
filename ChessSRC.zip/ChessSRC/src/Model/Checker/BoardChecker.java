package Model.Checker;

import java.util.List;

import Model.Color;
import Model.GameResult;
import Model.Move;
import Model.Position;

public interface BoardChecker {

  boolean kingInCheck(Color color);

  boolean isGameOver();

  boolean isPiecePinned(Position pos);

  List<Position> filterMoves(Position start, List<Position> ends);

  GameResult getGameResult();

}
