package Model.Board;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import Model.Checker.BoardChecker;
import Model.Checker.ChessBoardChecker;
import Model.Color;
import Model.GameResult;
import Model.Move;
import Model.MoveLog;
import Model.Pieces.ChessPieceFactory;
import Model.Pieces.Piece;
import Model.Pieces.PieceType;
import Model.Position;

public class ChessBoard implements Board {

  private BoardChecker boardChecker;
  private final Square[][] grid;
  private Color turn;
  private Square selectedSquare;

  private Stack<Move> log;

  public ChessBoard() {
    grid = new Square[8][8];
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        Position pos = new Position(r, c);
        grid[r][c] = new BoardSquare(pos);
      }
    }
    //setBoard();
    turn = Color.WHITE;
    boardChecker = new ChessBoardChecker(this);
    log = new Stack<>();
  }


  @Override
  public void setPieces() {
    setSide(Color.WHITE);
    setSide(Color.BLACK);
  }

  @Override
  public void placePiece(Piece piece, Position pos) {
    Square current = getSquare(pos);
    current.clear();
    current.setPiece(piece);
  }

  private void placePiece(Color color, PieceType type, int r, int c) {
    Square current = grid[r][c];
    Piece piece = ChessPieceFactory.buildPiece(color, type);
    current.setPiece(piece);
  }

  private void setSide(Color color) {
    int r = (color == Color.WHITE) ? 6 : 1;
    for (int c = 0; c < 8; c++) {
      placePiece(color, PieceType.PAWN, r, c);
    }
    r = (r == 6) ? r + 1 : r - 1;
    for (int c = 0; c <= 7; c += 7) {
      placePiece(color, PieceType.ROOK, r, c);
    }
    for (int c = 1; c <= 6; c += 5) {
      placePiece(color, PieceType.KNIGHT, r, c);
    }
    for (int c = 2; c <= 5; c += 3) {
      placePiece(color, PieceType.BISHOP, r, c);
    }
    placePiece(color, PieceType.QUEEN, r, 3);
    placePiece(color, PieceType.KING, r, 4);
  }

  private Square getSquare(Position pos) {
    return grid[pos.getRow()][pos.getCol()];
  }




  @Override
  public boolean isEmpty(Position pos) {
    return !getSquare(pos).isOccupied();
  }

  @Override
  public Piece getPiece(Position pos) {
    if (isEmpty(pos)) {
      throw new IllegalArgumentException("There is not piece here");
    }
    return this.getSquare(pos).getPiece();
  }




  @Override
  public void selectedPiece(Position pos) {
    Square current = getSquare(pos);
    if (current.isOccupied() && current.getPiece().getColor() != turn) {
      throw new IllegalArgumentException("You are not allowed to move " + turn.opposing().toString() + "'s pieces!");
    }
    if (!current.isOccupied()) {
      throw new IllegalArgumentException("There is not piece on "+pos + "!");
    }
    if (current.getPiece().getMoves(this, pos).isEmpty()) {
      throw new IllegalArgumentException("This piece has no valid moves!");
    }
    selectedSquare = getSquare(pos);
  }

  @Override
  public void unselectedPiece() {
    selectedSquare = null;
  }

  @Override
  public void movePiece(Position pos) {
    if (selectedSquare == null) {
      throw new IllegalStateException("You need to select a piece before you can move!");
    }
    if (!getPossibleMoves().contains(pos)) {
      throw new IllegalArgumentException(pos + " is not a valid move!");
    }

    Square current = getSquare(pos);
    Piece piece = selectedSquare.getPiece();
    current.setPiece(piece);
    Position start = selectedSquare.getPosition();
    selectedSquare.clear();
    selectedSquare = null;
    turn = turn.opposing();

    Move move = new Move(piece, start, pos);
    log.push(move);
  }

  @Override
  public void removePiece(Position pos) {
    Square current = grid[pos.getRow()][pos.getCol()];
    if (!current.isOccupied()) {
      throw new IllegalArgumentException("There is no piece here to remove");
    }
    current.clear();
  }

  @Override
  public void undoMove() {
    // dunno what to do here yet
  }




  @Override
  public boolean kingInCheck(Color color) {
    return boardChecker.kingInCheck(turn);
  }

  @Override
  public Color getTurn() {
    return turn;
  }


  @Override
  public boolean isGameOver() {
    return boardChecker.isGameOver();
  }

  @Override
  public GameResult getGameResult() {
    return boardChecker.getGameResult();
  }

  @Override
  public boolean isPiecePinned() {
    return selectedSquare != null && boardChecker.isPiecePinned(selectedSquare.getPosition());
  }





  @Override
  public Board getCopy() {
    return new ChessBoard(grid, turn);
  }

  private Square[][] getGridCopy(Square[][] grid) {
    if (grid.length != 8 || grid[0].length != 8) {
      throw new IllegalArgumentException("Grid must by 8x8");
    }
    Square[][] copy = new Square[8][8];
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        copy[r][c] = grid[r][c].getCopy();
      }
    }
    return copy;
  }

  private ChessBoard(Square[][] grid, Color turn) {
    this.grid = getGridCopy(grid);
    this.turn = turn;
    boardChecker = new ChessBoardChecker(this);
  }






  @Override
  public String[][] getTextGrid() {
    String[][] textGrid = new String[8][8];
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        Square current = grid[r][c];
        textGrid[r][c] = current.toString();
      }
    }
    return textGrid;
  }


  @Override
  public List<Position> getPossibleMoves() {
    if (selectedSquare == null) {
      return new ArrayList<>();
    }
    Piece piece = selectedSquare.getPiece();
    // Filter for checks
    Position start = selectedSquare.getPosition();
    List<Position> ends = piece.getMoves(this, selectedSquare.getPosition());
    return boardChecker.filterMoves(start, ends);
  }
}
