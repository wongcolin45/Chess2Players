package Model.Board;

import java.util.List;

import Model.Color;
import Model.GameResult;
import Model.Position;

public interface ViewableBoard {


  /**
   * Gets the current turn of the player.
   * @return the color turn
   */
  Color getTurn();

  /**
   * Checks is position is empty;
   * @param pos the position to check
   * @return true if empty, otherwise false
   */
  boolean isEmpty(Position pos);


  /**
   * Check if the king is in check.
   * @param color the color of the king
   * @return true if the king is in check, otherwise false
   */
  boolean kingInCheck(Color color);


  /**
   * Gets all the possible moves for the selected piece at that position.
   * If no piece is selected an empty list is given.
   */
  List<Position> getPossibleMoves();

  /**
   * Gets the String grid of the board.
   * @return the grid
   */
  String[][] getTextGrid();



  boolean isGameOver();

  /**
   * Gets the results of the game.
   * @return the result, either checkmate for white/black or stalemate
   * @throws IllegalStateException if the game is not over
   */
  GameResult getGameResult();


  /**
   * Checks if the piece is pinned.
   * @return true if the piece is pinned
   */
  boolean isPiecePinned();
}
