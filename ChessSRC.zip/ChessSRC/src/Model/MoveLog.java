package Model;

import java.util.Stack;

import Model.Pieces.Piece;

public class MoveLog {
  private final Stack<Move> log = new Stack<Move>();

  public void addMove(Piece piece, Position start, Position end) {
    log.push(new Move(piece, start, end));
  }

  public Move getLastMove() {
    return log.pop();
  }

  public boolean hasMoved(Position pos) {
    for (Move move : log) {
      if (move.getStart().equals(pos)) {
        return true;
      }
    }
    return false;
  }





}
