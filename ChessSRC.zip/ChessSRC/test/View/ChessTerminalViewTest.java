package View;

import org.junit.Before;
import org.junit.Test;

import Model.Board.Board;
import Model.Board.ChessBoard;


public class ChessTerminalViewTest {
  private Board board;

  @Before
  public void init() {
    board = new ChessBoard();
    board.setPieces();
  }

  @Test
  public void testInitialBoardWhitePOV() {
    ChessView view = new ChessTerminalView(board);
    System.out.println(view);
  }

  @Test
  public void testInitialBoardBlackPOV() {
    ChessView view = new ChessTerminalView(board);
    view.flip();
    System.out.println(view);
  }
}